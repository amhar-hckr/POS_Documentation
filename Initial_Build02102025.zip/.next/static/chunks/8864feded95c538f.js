__turbopack_load_page_chunks__("/_app", [
  "static/chunks/e60ef129113f6e24.js",
  "static/chunks/85cf24e3fa11492c.js",
  "static/chunks/turbopack-f1b2bd3ff968fe5b.js"
])
