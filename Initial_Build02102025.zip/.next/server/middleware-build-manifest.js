globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": [
      "static/chunks/e60ef129113f6e24.js",
      "static/chunks/85cf24e3fa11492c.js",
      "static/chunks/turbopack-f1b2bd3ff968fe5b.js"
    ],
    "/_error": [
      "static/chunks/17722e3ac4e00587.js",
      "static/chunks/85cf24e3fa11492c.js",
      "static/chunks/turbopack-fbcd7ce2ef98222e.js"
    ]
  },
  "devFiles": [],
  "ampDevFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/1e3143829aa7527a.js",
    "static/chunks/5a50ee1d1bd5f6b0.js",
    "static/chunks/6d17a196719d2d8a.js",
    "static/chunks/27d09400ac964213.js",
    "static/chunks/turbopack-4e19a13b6b01cefd.js"
  ],
  "ampFirstPages": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
,"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js",

];