var R=require("../../chunks/[turbopack]_runtime.js")("server/app/favicon.ico/route.js")
R.c("server/chunks/[root-of-the-server]__a69459cc._.js")
R.c("server/chunks/node_modules_next_dist_77fd8386._.js")
R.c("server/chunks/[root-of-the-server]__8eb261cc._.js")
R.c("server/chunks/node_modules_next_dist_03a3c8f9._.js")
R.m(15934)
R.m(90295)
module.exports=R.m(90295).exports
